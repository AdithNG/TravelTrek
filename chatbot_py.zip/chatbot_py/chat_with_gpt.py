# chat_with_gpt_flask.py
from flask import Flask, render_template, request
import openai

app = Flask(__name__)

# Set your OpenAI GPT API key
openai.api_key = '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'

def get_gpt_response(user_message):
    prompt = f"User: {user_message}\nAssistant:"
    
    response = openai.ChatCompletion.create(
        model="gpt-4",  # Choose the GPT model you want to use
        messages=[
            {"role": "system", "content": "You are a travel assistant tasked with giving information about tourist attractions from the user's input along with hotels and their pricing from the inputted destination"},
            {"role": "user", "content": user_message},
        ],
    )

    return response['choices'][0]['message']['content'].strip()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    response = get_gpt_response(user_input)
    return {'user_input': user_input, 'gpt_response': response}

if __name__ == "__main__":
    app.run(debug=True)
